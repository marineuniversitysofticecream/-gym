package kr.ac.mmu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.google.firebase.analytics.FirebaseAnalytics;


public class SignUpActivity extends AppCompatActivity {
    private FirebaseAnalytics mFirebaseAnalytics;     //파이어베이스 인증
    //private DatabaseReference mDatabaseRef; //실시간 데이터베이스
    private EditText mEtEmail, mEtPwd, mEtName, mEtPhoneNum;
    private Button mBtnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        // 가입하기 버튼 클릭 이벤트 설정
        mBtnSignUp = findViewById(R.id.buttonSignUp);
        mBtnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 가입하기 버튼이 클릭되었을 때 실행되는 부분
                // Intent를 사용하여 MainActivity로 전환
                Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
                startActivity(intent); // MainActivity로 이동
                finish(); // 현재 SignUpActivity 종료
            }
        });
    }
}